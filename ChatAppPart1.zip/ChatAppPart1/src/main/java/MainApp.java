/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author thape
 */
import java.util.Scanner; 

public class MainApp {
      public static void main(String[] args){ 
    
      //Created Scanner 
        Scanner input = new Scanner(System.in); 

          
        //Create an object 
        Login login = new Login(); 

        
        //--- RESGISTRATION SECTION --- 
        System.out.println("=== User Registration ==="); 

         
        System.out.print("Enter a username: "); 
        String username = input.nextLine(); 

         

        System.out.print("Enter a password: "); 
        String password = input.nextLine(); 

         

        System.out.print("Enter your South African phone number (+27...): "); 
        String phone = input.nextLine(); 

         

        //Call the registerUser method and store the messahe it reutrns 
        String response = login.registerUser(username, password, phone); 


        //Show the registration message 
        System.out.println(response); 

        
        //=== LOGIN SECTION === 
        System.out.println("\n=== USER LOGIN ==="); 

         

        System.out.print("Enter your username: "); 
        String loginUsername = input.nextLine(); 

         

        System.out.print("Enter your password: "); 
        String loginPassword = input.nextLine(); 

         

        //Call loginUser to check if details match the stored ones 
        boolean loggedIn = login.loginUser(loginUsername, loginPassword); 

         

        //Print out the correct login message 
        String loginMessage = login.returnLoginStatus(loggedIn); 
        System.out.println(loginMessage); 
} 
}

