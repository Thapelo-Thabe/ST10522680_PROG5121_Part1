/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppart1;

/**
 *
 * @author thape
 */
public class ChatAppPart1 {

    public static void main(String[] args) {
      
    }
}
