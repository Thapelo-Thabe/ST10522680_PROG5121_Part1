/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author thape
 */
public class LoginTest {
  
    Login login = new Login();

    // User Test
    @Test
    public void testValidUsername() {
        assertTrue(login.checkUserName("tt_1"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(login.checkUserName("super"));
    }

    @Test
    public void testInvalidUsernameMessage() {
        String result = login.registerUser("super ","Pas@123", "+27831234107");

        assertEquals(
            "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
            result
        );
    }

    // Password tests
    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Pass@123"));
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testInvalidPasswordMessage() {
        String result = login.registerUser("tt_1", "password", "+27831234107");

        assertEquals(
            "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
            result
        );
    }

    // Phone number testing
    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27831234107"));
    }

    @Test
    public void testInvalidPhoneNumber() {
        assertFalse(login.checkCellPhoneNumber("0831234107"));
    }

    @Test
    public void testInvalidPhoneMessage() {
        String result = login.registerUser("tt_1 ","Pass@123", "0831234107");

        assertEquals(
            "Cell phone number incorrectly formatted or does not contain international code.",
            result
        );
    }

    // Registration testing
    @Test
    public void testSuccessfulRegistration() {
        String result = login.registerUser("tt_1", "Pass@123", "+27831234107");

        assertEquals("User registered successfully.", result);
    }


    // Login testing
    @Test
    public void testLoginSuccess() {
        login.registerUser("tt_1", "Pass@123", "+27831234107");

        assertTrue(login.loginUser("tt_1", "Pass@123"));
    }

    @Test
    public void testLoginFailure() {
        login.registerUser("tt_1", "Pass@123", "+27831234107");

        assertFalse(login.loginUser("wrong", "wrong"));
    }
}

 
    
